const stockTicker = (state = {}, action) => {
    switch (action.type) {
        default:
            return state;
    }
};

export default stockTicker;
